package com.k118.chat.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.k118.chat.data.model.User
import com.k118.chat.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    user: User,
    onBackClicked: () -> Unit,
    onUpdateStatus: (String) -> Unit,
    onUpdateBio: (String) -> Unit,
    onSignOut: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBackClicked) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = { Text("My Profile", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = K118DarkBackground)
            )
        },
        containerColor = K118DarkBackground
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(20.dp)
        ) {
            // Profile Photo
            AsyncImage(
                model = user.photoURL,
                contentDescription = user.displayName,
                modifier = Modifier.size(108.dp).clip(CircleShape)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(user.displayName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(user.email, fontSize = 14.sp, color = K118TextSecondary)

            Spacer(modifier = Modifier.height(24.dp))
            // Status selector
            Surface(shape = RoundedCornerShape(16.dp), color = K118DarkSurface, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AVAILABILITY STATUS", fontSize = 11.sp, color = K118TextMuted, fontWeight = FontWeight.Bold)
                    listOf("online" to "Online", "away" to "Away", "offline" to "Offline").forEach { (code, label) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().clickable { onUpdateStatus(code) }.padding(8.dp)
                        ) {
                            Text(label, color = Color.White, modifier = Modifier.weight(1f))
                            if (user.status == code) Icon(Icons.Default.Check, contentDescription = null, tint = K118PurpleLight)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out")
            }
        }
    }
}