package com.k118.chat.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.k118.chat.data.model.User
import com.k118.chat.ui.theme.*
import com.k118.chat.ui.viewmodel.ChatListUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    currentUser: User,
    uiState: ChatListUiState,
    onFriendClicked: (User) -> Unit,
    onProfileClicked: () -> Unit,
    onNewChatClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("K118", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = onProfileClicked) {
                        Box {
                            AsyncImage(
                                model = currentUser.photoURL,
                                contentDescription = "Profile",
                                modifier = Modifier.size(36.dp).clip(CircleShape)
                            )
                            Box(
                                modifier = Modifier.size(10.dp).clip(CircleShape).background(K118OnlineGreen).align(Alignment.BottomEnd)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = K118DarkBackground)
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewChatClicked, containerColor = K118PurplePrimary) {
                Icon(Icons.Default.AddComment, contentDescription = "New Chat", tint = Color.White)
            }
        },
        containerColor = K118DarkBackground
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            // Online Friends Tray
            val onlineFriends = uiState.friends.filter { it.isOnline }
            if (onlineFriends.isNotEmpty()) {
                Text("ONLINE NOW (${onlineFriends.size})", fontSize = 12.sp, color = K118OnlineGreen, modifier = Modifier.padding(16.dp, 8.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(onlineFriends) { friend ->
                        OnlineFriendAvatar(friend = friend, onClick = { onFriendClicked(friend) })
                    }
                }
            }

            // Conversations
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(uiState.friends) { friend ->
                    FriendChatItem(friend = friend, onClick = { onFriendClicked(friend) })
                }
            }
        }
    }
}