package com.k118.chat.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.InsertEmoticon
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.k118.chat.data.model.Message
import com.k118.chat.data.model.User
import com.k118.chat.ui.theme.*
import com.k118.chat.ui.viewmodel.ActiveChatUiState
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    currentUser: User,
    chatState: ActiveChatUiState,
    onBackClicked: () -> Unit,
    onInputChanged: (String) -> Unit,
    onSendMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val recipient = chatState.recipient

    // Auto scroll to bottom when messages update
    LaunchedEffect(chatState.messages.size) {
        if (chatState.messages.isNotEmpty()) {
            listState.animateScrollToItem(chatState.messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBackClicked) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                title = {
                    if (recipient != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                if (recipient.photoURL.isNotBlank()) {
                                    AsyncImage(
                                        model = recipient.photoURL,
                                        contentDescription = recipient.displayName,
                                        modifier = Modifier.size(40.dp).clip(CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier.size(40.dp).clip(CircleShape).background(K118PurpleDark),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(recipient.displayName.take(1).uppercase(), color = Color.White)
                                    }
                                }
                                // Online status dot
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (recipient.isOnline) K118OnlineGreen else K118OfflineGray)
                                        .align(Alignment.BottomEnd)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(recipient.displayName, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                                Text(
                                    text = if (recipient.isOnline) "Online" else "Offline",
                                    fontSize = 12.sp,
                                    color = if (recipient.isOnline) K118OnlineGreen else K118TextMuted
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = K118DarkSurface)
            )
        },
        bottomBar = {
            Surface(color = K118DarkSurface, tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.InsertEmoticon, contentDescription = "Emoji", tint = K118TextSecondary)
                    }
                    OutlinedTextField(
                        value = chatState.inputText,
                        onValueChange = onInputChanged,
                        placeholder = { Text("Type a message...", color = K118TextMuted, fontSize = 14.sp) },
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                    )
                    IconButton(
                        onClick = onSendMessage,
                        enabled = chatState.inputText.isNotBlank() && !chatState.isSending,
                        modifier = Modifier.size(46.dp).background(if (chatState.inputText.isNotBlank()) K118PurplePrimary else K118DarkSurfaceVariant, CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        },
        containerColor = K118DarkBackground
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize().padding(innerPadding)
        ) {
            items(chatState.messages) { message ->
                ChatMessageBubble(message = message, isSentByMe = message.senderId == currentUser.uid)
            }
        }
    }
}