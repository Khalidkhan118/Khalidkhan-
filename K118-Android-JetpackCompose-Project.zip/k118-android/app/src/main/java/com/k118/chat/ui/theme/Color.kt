package com.k118.chat.ui.theme

import androidx.compose.ui.graphics.Color

// K118 Brand Palette based on the official purple gradient logo & online status dot
val K118PurplePrimary = Color(0xFF7C3AED)
val K118PurpleDark = Color(0xFF5B21B6)
val K118PurpleLight = Color(0xFFA78BFA)
val K118PurpleGradientStart = Color(0xFF6A11CB)
val K118PurpleGradientEnd = Color(0xFF8B5CF6)

// Online Status Green (matching the green dot on the K118 logo)
val K118OnlineGreen = Color(0xFF10B981)
val K118OfflineGray = Color(0xFF6B7280)
val K118AwayOrange = Color(0xFFF59E0B)

// Dark Theme Surfaces
val K118DarkBackground = Color(0xFF0D0D18)
val K118DarkSurface = Color(0xFF161628)
val K118DarkSurfaceVariant = Color(0xFF22223D)
val K118DarkBorder = Color(0xFF2E2E52)

// Message Bubbles
val K118SentBubble = Color(0xFF7C3AED)
val K118ReceivedBubble = Color(0xFF1E1E34)

// Text Colors
val K118TextPrimary = Color(0xFFF8FAFC)
val K118TextSecondary = Color(0xFF94A3B8)
val K118TextMuted = Color(0xFF64748B)